'''#####-----Build File-----#####'''
buildfile = 'https://the666mafia.com/txt/simplebuilds.txt'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://the666mafia.com/txt/wizard_notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
