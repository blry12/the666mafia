'''#####-----Build File-----#####'''
buildfile = 'https://the666mafia.com/nxtflix/txt/wiz_builds.txt'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://the666mafia.com/nxtflix/txt/wizard_notify.txt'

'''#####-----Changelog Directory-----#####'''
changelog_dir  = 'https://the666mafia.com/nxtflix/txt/changelog/'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
